class SuperheroDetailResponse {
  final String id;
  final String name;
  final String url;
  final String realName;
  final String aliases;
  final PowerstatsResponse powerstatsResponse;
  final AppearanceResponse appearanceResponse;

  //final String herostats;
  SuperheroDetailResponse({
    required this.id,
    required this.name,
    required this.url,
    required this.realName,
    required this.aliases,
    required this.powerstatsResponse,
    required this.appearanceResponse,
    
  });
  factory SuperheroDetailResponse.fromJson(Map<String, dynamic> json) {
    return SuperheroDetailResponse(
      id: json["id"],
      name: json["name"],
      url: json["image"]["url"],
      realName: json["biography"]["full-name"],
      aliases: (json["biography"]["aliases"] as List<dynamic>)
          .where((alias) => alias != null && alias.toString().trim().isNotEmpty)
          .join(", "),
      powerstatsResponse: PowerstatsResponse.fromJson(json["powerstats"]),
      appearanceResponse: AppearanceResponse.fromJson(json["appearance"]),
    );
  }
}

class AppearanceResponse {
  final String gender;
  final String race;
  final String height;
  final String weight;

  AppearanceResponse({
    required this.gender,
    required this.race,
    required this.height,
    required this.weight,
  });
  factory AppearanceResponse.fromJson(Map<String, dynamic> json) {
    return AppearanceResponse(
      gender: json["gender"],
      race: json["race"],
      height: (json["height"] is List && json["height"].length > 1)
          ? json["height"][1] // segundo elemento, en cm
          : "",
      weight: (json["weight"] is List && json["weight"].length > 1)
          ? json["weight"][1] // segundo elemento, en kg
          : "",
    );
  }
}

class PowerstatsResponse {
  final String intelligence;
  final String strength;
  final String speed;
  final String durability;
  final String power;
  final String combat;

  PowerstatsResponse({
    required this.intelligence,
    required this.strength,
    required this.speed,
    required this.durability,
    required this.power,
    required this.combat,
  });

  factory PowerstatsResponse.fromJson(Map<String, dynamic> json) {
    return PowerstatsResponse(
      intelligence: json["intelligence"],
      strength: json["strength"],
      speed: json["speed"],
      durability: json["durability"],
      power: json["power"],
      combat: json["combat"],
    );
  }
}
